import React from 'react'

const Callibrate = () => {
  return (
    <div className="skills__content">
      <h3 className="skills__title">C Callibrate</h3>
      <div className="skills__box">
        <p>Make necessary course corrections to further align actions with the desired result</p>
      </div>
    </div>
  )
}

export default Callibrate
