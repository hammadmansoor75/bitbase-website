import React from 'react';

export default function Frontend() {
  return (
    <div className="skills__content">
      <h3 className="skills__title">P Prepare</h3>
      <div className="skills__box">
        <p>Understand your business and its revenue funnel</p>
      </div>
    </div>
  );
}
