import React from 'react';

export default function Backend() {
  return (
    <div className="skills__content">
      <h3 className="skills__title">A Act</h3>
      <div className="skills__box">
        <p>Identify your opportunities and attack leverage points within that funnel</p>
      </div>
    </div>
  );
}
